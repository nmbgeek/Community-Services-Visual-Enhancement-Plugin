# Community Services Visual Enhancement plugin

This is the code used in the Community Services Visual Enhancement plugin which will hopefully be in the Google Extension store very soon. You may also download the contents here, enable Chrome Developer mode, and load as an "unpacked" extension.

https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/#load-unpacked

![Community Services Preview](cs-preview.png)
